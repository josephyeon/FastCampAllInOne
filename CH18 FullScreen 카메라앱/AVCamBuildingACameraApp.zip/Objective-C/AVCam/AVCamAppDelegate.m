/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The app's delegate object.
*/

#import "AVCamAppDelegate.h"

@implementation AVCamAppDelegate

@end
